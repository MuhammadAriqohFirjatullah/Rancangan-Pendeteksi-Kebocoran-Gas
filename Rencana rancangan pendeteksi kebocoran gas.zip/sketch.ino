const int sensorGas = 34;
const int led = 2;
const int buzzer = 4;

void setup() {
  pinMode(led, OUTPUT);
    pinMode(buzzer, OUTPUT);
      Serial.begin(115200);
      }

      void loop() {
        int nilaiGas = analogRead(sensorGas);

          Serial.print("Nilai Gas: ");
            Serial.println(nilaiGas);

              if (nilaiGas > 2000) {
                  digitalWrite(led, HIGH);
                      tone(buzzer, 1000);
                          Serial.println("BAHAYA! GAS BOCOR TERDETEKSI!");
                            } else {
                                digitalWrite(led, LOW);
                                    noTone(buzzer);
                                        Serial.println("Kondisi Aman");
                                          }

                                            delay(500);
                                            }